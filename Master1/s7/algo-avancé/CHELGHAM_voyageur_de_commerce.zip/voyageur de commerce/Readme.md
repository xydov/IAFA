@ chelgham Nouh 22011152
@ exemple utilisation : 
@	hill-climbing : python3 voyageurDeCommerce.py tsp5.txt 0 50 10 1 
			-> le 0 répresente la taille de la liste tabou , on le met à 0 parce qu'on ne l'utilise pas dans cette algo .
			-> le 50 répresente le nombre de déplacement max 
			-> le 10 répresente le nombre d' essaies 
			-> le 1 représente l'algo ( 1 pour hill climbing / 2 pour tabou ) 


@	Tabou	      : python3 voyageurDeCommerce.py tsp5.txt 5 50 0 2 
			-> le 5 répresente la taille de la liste tabou ici 
			-> le 50 est inchangé , le nombre de déplacements max 
			-> le 0 ici , le nombre d'essaies qui est à 0 vu que y'a pas ca dans l'algo du tabou 
			-> 2 répresente l'algo (1 pour hill climbing / 2 pour tabou ) 

@ dans le cas ou une erreur est faite , un message d'erreur vous guidera : 
		python3 voyageurDeCommerce Instance_Name, SIZE, MAX_DEPL, MAX_ESSAIE, ALGO

## dans le rapport , j'ai pas mentionné les voisins / solutions finaux et initiaux , vous les verrais lors de l'éxecution .
## J'ai du dépasser la taille maximale pour le rapport ( 2 - 3 pages ) et j'ai utilisé 6 pages pour bien tout détailler (deux tableau pour chaque instance hill climbing et tabou).
## La partie PLNE a été modifiée le 23/12 à 22h donc cette partie n'apparait pas dans le rapport .

  
