import sys
from random import randrange
import math

#verifier qu'on recupere 4 parametres 
if len(sys.argv) != 5:
    print('Usage: python <fichier avec les données> <MAX_depl> <Max_essaies> <tailleListeTabou>')
    exit(-1)

#ouvrir fichier en mode lecture
fichier = open(sys.argv[1], "r")
#on recupere les lignes du fichier
lignes = fichier.readlines()
#on recupere le nombre de villes
n = int(lignes[0])
#on recupere le max de deplacement
Max_depl = int(sys.argv[2])
#on recupere le max d'essaies
Max_essaies = int(sys.argv[3])
#on recupere la taille de la liste tabou
tailleListeTabou = int(sys.argv[4])

#fonction qui renvoie un vecteur de n villes tirees aleatoirement 
def solution_initiale(n):
    vec = []
    numvilles = list(range(1,n+1))
    while len(numvilles) != 0:
        rand = randrange(len(numvilles))
        vec.append(numvilles[rand])
        numvilles.pop(rand)
    return vec

#fonction qui calcule la valeur de cette solution 
def calcul_val(sol):
    nbvilles = 0
    val = 0
    for i in sol:
        ville = lignes[i].split('\t')
        ville[2] = ville[2][:2]
        if nbvilles == 0:
            tmp = ['0', '0', '0']
        x2 = int(tmp[1])
        y2 = int(tmp[2])
        x1 = int(ville[1])
        y1 = int(ville[2])

        x1moinsx2 = x1 - x2
        y1moinsy2 = y1 - y2
        valocal = math.sqrt((x1moinsx2*x1moinsx2) + (y1moinsy2*y1moinsy2))

        val = val + valocal
        tmp = ville
        nbvilles = nbvilles + 1
    
    derniere_ville = lignes[sol[len(sol)-1]].split('\t')
    derniere_ville[2] = derniere_ville[2][:2]
    x1 = int(derniere_ville[1])
    y1 = int(derniere_ville[2])

    x = math.sqrt(x1*x1 + y1*y1)
    val = val + x

    return val

#fonction qui renvoie la meilleur solution voisine
def meilleur_voisin(initsol,n):
    meilleurvoisin = []
    solution = float('inf')

    for i in range(0,n):
        for y in range(i+1,n):
            voisin = initsol.copy()
            tmp = voisin[y]
            voisin[y] = voisin[i]
            voisin[i] = tmp
            solution_locale = calcul_val(voisin)
            if solution_locale < solution:
                solution = solution_locale
                meilleurvoisin = voisin
    return meilleurvoisin

#fonction de la methode steepest Hill-Climbing
def steepestHillClimbing( Max_depl,n):
    initsol = solution_initiale(n)
    depl = 0
    sol = initsol
    voisin = meilleur_voisin(initsol, n)
    while calcul_val(voisin) < calcul_val(sol) and depl < Max_depl:
        depl = depl + 1
        sol = voisin
        voisin = meilleur_voisin(sol, n)
    print('Solution initiale:', initsol)
    print('Solution atteinte:', sol, 'en', depl, 'deplacements')
    return sol

def steepestHillClimbingV2(n,Max_depl,Max_essaies):
    solfinal = []
    for i in range(Max_essaies):
        print('\tEssaie nº',i)
        sol = solution_initiale(n)
        print('\t\tSolution initiale:', sol)
        voisin = meilleur_voisin(sol, n)
        depl = 0
        while calcul_val(voisin) < calcul_val(sol) and depl < Max_depl :
            sol= voisin
            voisin = meilleur_voisin(sol, n)
            depl = depl + 1

        if i == 0 or calcul_val(sol) < calcul_val(solfinal):
            solfinal = sol
       
        print('\t\tSolution atteinte:', solfinal, 'en', depl, 'deplacements')
        
    return solfinal

#fonction de la methode tabou
def listeTabou(n, Max_depl,tailleListeTabou):
    sol = solution_initiale(n)
    print('\tSolution initiale:', sol)
    tabou = []
    depl = 0
    msol = sol
    stop = False

    while depl < Max_depl and not stop :
        voisinsNonTabou = voisins_non_tabou(n,tabou, sol)
        if len(voisinsNonTabou) != 0:
            tmp = meilleur_voisin_non_tabou(voisinsNonTabou)            
        else :
            stop = True
            
        tabou.append(sol)
        if len(tabou) > tailleListeTabou:
            tabou.pop(0)
        if calcul_val(tmp) < calcul_val(msol) :
            msol = tmp
            
        depl = depl + 1
        sol = tmp
        
    print('\t\tSolution atteinte:', msol, 'en', depl, 'deplacements')
    return msol

#fonction qui calcule les voisins non tabou d'une solution
def voisins_non_tabou(n,tabou, sol):
    voisins_non_tabou = []
    for i in range(n):
        for y in range(i+1,n):
            voisin = sol.copy()
            tmp = voisin[y]
            voisin[y] = voisin[i]
            voisin[i] = tmp
            if voisin not in tabou :
                voisins_non_tabou.append(voisin)
    return voisins_non_tabou

#focntion qui recupere le mailleur voisin d'une liste de voisins non tabou
def meilleur_voisin_non_tabou(voisinsNonTabou):
    mvoisin = voisinsNonTabou[0]
    for voisin in voisinsNonTabou :
        if calcul_val(voisin) < calcul_val(mvoisin) :
            mvoisin = voisin
    return mvoisin

x = solution_initiale(n)
print("solution initiale = ",x)
valx = calcul_val(x)
print("valeur de la solution = ",valx)
meilleurvoisin = meilleur_voisin(x,n) 
print("le meilleur voisin", meilleurvoisin)
valmeilleur = calcul_val(meilleur_voisin(x,n))
print("valeur du meilleur voisin ",valmeilleur)
print('Recherche avec l\'algorithme steepestHillClimbing classique:')
steepestHillClimbing(Max_depl,n)
print('Recherche avec l\'algorithme steepestHillClimbing avec redémarrages:')
steepestHillClimbingV2(n, Max_depl,Max_essaies)
print('La methode de tabou')
listeTabou(n, Max_depl,tailleListeTabou)