from pymongo import MongoClient
import sys
import time

def requete_1(db):
    #1. obtenir la liste des restaurants de la ville de Greenville
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("1. obtenir la liste des restaurants de la ville de Greenville")
    print("+----------------------------------------------Result------------------------------------------------+")
    restaurants_greenville = db.restaurants.find({"ville": "Greenville"}, {"business_id":1, "name":1, "ville":1})
    for restaurant in restaurants_greenville:
        print("Business ID: {}, Name: {}, City:{}".format(restaurant["business_id"], restaurant['name'], restaurant["ville"]))
    print("+----------------------------------------------------------------------------------------------------+")

def requete_2(db):
    #2. obtenir les utilisateurs qui ont rédigé des reviews avec une note inférieure ou égale à 2.0
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("2. obtenir les utilisateurs qui ont rédigé des reviews avec une note inférieure ou égale à 2.0")
    print("+----------------------------------------------Result------------------------------------------------+")
    users_low_ratings = db.users.find({"reviews": {"$elemMatch": {"rating": {"$lte": 2.0}}}})
    for user in users_low_ratings:
        print("User ID : {}, Name : {}".format(user['user_id'], user['name']))
    print("+----------------------------------------------------------------------------------------------------+")

def requete_3(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("3. Obtenez les noms et adresses des restaurants de la ville de New Castle qui")
    print("entrent dans la catégorie Mexican")
    print("+----------------------------------------------Result------------------------------------------------+")
    #3. Obtenez les noms et adresses des restaurants de la ville de New Castle qui entrent dans la catégorie Mexican
    restaurants = db.restaurants.find(
            {"ville": "New Castle",
             "categories": 'Mexican'
            }, 
            {"_id":0,
             "name": 1,
             "adresse": 1,
             "categories":1}
        )
    #restaurants = db.restaurants.find({"ville": "New Castle", "categories": {"$regex": 'Mexican', "$options": "i"}}, {"name": 1, "adresse": 1, "categories":1})

    for restaurant in restaurants:
        print(restaurant)
    print("+----------------------------------------------------------------------------------------------------+")

def requete_4(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("4. Obtenez le nombre d’utilisateurs qui n’ont pas d’ami")
    print("+----------------------------------------------Result------------------------------------------------+")
    #4. Obtenez le nombre d’utilisateurs qui n’ont pas d’ami
    users_no_friends_count = db.users.count_documents({"friends": {"$size": 0}})
    print("Users number: ",users_no_friends_count)
    print("+----------------------------------------------------------------------------------------------------+")

def requete_5(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("5. Obtenez le nombre de restaurants pour chaque ville")
    print("+----------------------------------------------Result------------------------------------------------+")
    #5. Obtenez le nombre de restaurants pour chaque ville
    restaurants_per_city = db.restaurants.aggregate([
                        {"$group": {"_id": "$ville", "count": {"$sum": 1}}},
                        {"$project" : {"_id":1, "count":1}}
                    ])
    for result in restaurants_per_city:
        print(result)
    print("+----------------------------------------------------------------------------------------------------+")

def requete_6(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("6. Obtenez la note globale la plus élevée obtenue par un restaurant")
    print("+----------------------------------------------Result------------------------------------------------+")
    #6. Obtenez la note globale la plus élevée obtenue par un restaurant
    highest_rating = db.restaurants.aggregate([
        { "$sort": { "rating": -1 } },
        { "$limit": 1 },
        { "$project": { "_id": 0, "rating": 1 } }
    ])
    print("The best global rating : ",next(highest_rating)['rating']) 
    print("+----------------------------------------------------------------------------------------------------+")

def requete_7(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("7. Obtenez les restaurants qui proposent au moins 3 ambiances différentes")
    print("+----------------------------------------------Result------------------------------------------------+")
    #7. Obtenez les restaurants qui proposent au moins 3 ambiances différentes
    #restaurants = db.restaurants.find({"$expr": {"$gte": [{"$size": "$ambiences"}, 3]}}, {"business_id":1,"name": 1, "ambiences":1})
    restaurants = db.restaurants.find({"more_than_3":1}, {"business_id":1,"name": 1, "ambiences":1})

    for restaurant in restaurants:
        print("Business ID: {}, Name: {}, Ambiences:{}".format(restaurant["business_id"], restaurant['name'], restaurant["ambiences"]))
    print("+----------------------------------------------------------------------------------------------------+")

def requete_8(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("8. Obtenez les identifiants des restaurants qui ont été évalués par l’un des utilisateurs")
    print("correspondants 'n2UpKhkU2N-66a1QQzrjYw', 'ucD25otZ0uqWPSJnl4muQQ'")
    print("+----------------------------------------------Result------------------------------------------------+")
    #8. Obtenez les identifiants des restaurants qui ont été évalués par l’un des utilisateurs correspondants "n2UpKhkU2N-66a1QQzrjYw", "ucD25otZ0uqWPSJnl4muQQ"
    restaurants = db.restaurants.find({"users.user_id": {
                                            "$in": [
                                                "n2UpKhkU2N-66a1QQzrjYw",
                                                "ucD25otZ0uqWPSJnl4muQQ"
                                                ]
                                            }
                                        },
                                        {"business_id":1}
                                    )
    for restaurant in restaurants:
        print("Businnes ID : {}".format(restaurant["business_id"]))
    print("+----------------------------------------------------------------------------------------------------+")

def requete_9(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("9. Obtenez les identifiants Yelp et noms des utilisateurs qui ont évalué")
    print("les deux restaurants d’identifiants Yelp 'UBX73ZWgCdgom4nv0UeGvg', '51Fo_uY52A5oaI8YTHU5yg'")
    print("+----------------------------------------------Result------------------------------------------------+")
    #9. Obtenez les identifiants Yelp et noms des utilisateurs qui ont évalué les deux restaurants d’identifiants Yelp "UBX73ZWgCdgom4nv0UeGvg", "51Fo_uY52A5oaI8YTHU5yg"
    users = db.users.find({"reviews":{
                                "$elemMatch": {
                                    "business_id":{
                                        "$in": ["UBX73ZWgCdgom4nv0UeGvg", "51Fo_uY52A5oaI8YTHU5yg"]
                                        }
                                    }
                                }
                            },
                            {"user_id":1, "name":1}
                            )
    for user in users:
        print("User ID: {}, Name: {}".format(user["user_id"], user["name"]))
    print("+----------------------------------------------------------------------------------------------------+")

def requete_10(db):
    print("+---------------------------------------------------Request----------------------------------------------------+")
    print("10. Obtenez le nombre de restaurants qui ont reçu des notes au-dessus de 4.0 et également en-dessous de 2.0")
    print("+---------------------------------------------------Result-----------------------------------------------------+")
    #10. Obtenez le nombre de restaurants qui ont reçu des notes au-dessus de 4.0 et également en-dessous de 2.0
    restaurants_high_low_ratings_count = db.restaurants.count_documents({
                                                    "$or": [
                                                        {"rating": {"$gt": 4.0}}, 
                                                        {"rating": {"$lt": 2.0}}
                                                        ]
                                                    }
                                                )
    print("Restaurants number: ",restaurants_high_low_ratings_count)
    print("+--------------------------------------------------------------------------------------------------------------+")

def requete_11(db):
    #11. Obtenez les différentes catégories associées aux restaurants évalués par l’utilisateur d’identifiant Yelp "FlXBpK_YZxLo27jcMdII1w"
    print("+------------------------------------------------------------------Request-------------------------------------------------------------------+")
    print("11. Obtenez les différentes catégories associées aux restaurants évalués par l’utilisateur d’identifiant Yelp 'FlXBpK_YZxLo27jcMdII1w'")
    print("+------------------------------------------------------------------Result--------------------------------------------------------------------+")
    categories = db.users.aggregate([
        {"$match": {"user_id": "FlXBpK_YZxLo27jcMdII1w"}}, # on filtre les utilisateurs ayant l'user_id égal à "FlXBpK_YZxLo27jcMdII1w".
        {"$unwind": "$reviews"}, # décomposer le tableau reviews pour traiter chaque element
        {"$lookup": {"from": "restaurants", 
                     "localField": "reviews.business_id", 
                     "foreignField": "business_id", 
                     "as": "restaurant_info"}}, # effectue une jointure entre les collections users et restaurants.
        {"$unwind": "$restaurant_info"}, # décomposer le tableau créé par la jointure parce que on peut avoir plusieurs restaurants évalués par un seul user
        {"$group": {"_id": "$restaurant_info.categories"}}, #  regroupe les documents en fonction de la valeur du champ categories.
        {"$unwind": '$_id'}
    ])
    for result in categories:
        print(result["_id"])
    print("+--------------------------------------------------------------------------------------------------------------------------------------------+")    

def requete_12(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("12. Obtenez le nombre d’amis de chaque utilisateur (y compris pour ceux qui n’en ont pas)")
    print("+----------------------------------------------Result------------------------------------------------+")

    users = db.users.aggregate([
        {"$project": {"user_id": 1, "name": 1, "friends_count": 1}}
    ])
    for result in users:
        print(result)
    print("+----------------------------------------------------------------------------------------------------+")

def requete_13(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("13. Obtenez les identifiants des amis communs aux utilisateurs correspondant aux identifiants")
    print("Yelp 'FlXBpK_YZxLo27jcMdII1w', '6Mv-qMJyxSokCu8YFM1o0A'")
    print("+----------------------------------------------Result------------------------------------------------+")
    #13. Obtenez les identifiants des amis communs aux utilisateurs correspondant aux identifiants Yelp "FlXBpK_YZxLo27jcMdII1w", "6Mv-qMJyxSokCu8YFM1o0A"
    common_friends = db.users.aggregate([
        {"$match": {"user_id": {"$in": ["FlXBpK_YZxLo27jcMdII1w", "6Mv-qMJyxSokCu8YFM1o0A"]}}},
        {"$group": {
            "_id": 0,
            "friends1": { "$first": "$friends" },
            "friends2": { "$last": "$friends" }
        }},
        {"$project": {"common_friends": { "$setIntersection": [ "$friends1", "$friends2" ] }, "_id": 0}} 
    ])

    for result in common_friends:
        print(result)
    print("+----------------------------------------------------------------------------------------------------+")

def requete_14(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("14. Obtenez les commentaires d’utilisateurs qui mentionnent le mot amazing")
    print("+----------------------------------------------Result------------------------------------------------+")
    #14. Obtenez les commentaires d’utilisateurs qui mentionnent le mot amazing
    amazing_reviews = db.users.find({"reviews":{
                                        "$elemMatch": {
                                            "text": {"$regex": "amazing", "$options": "i"}}}})
    for review in amazing_reviews:
        print(review["reviews"])
    print("+----------------------------------------------------------------------------------------------------+")

def requete_15(db):
    print("+----------------------------------------------Request-----------------------------------------------+")
    print("15. Obtenez les 3 prénoms d’utilisateurs les plus présents dans la base")
    print("+----------------------------------------------Result------------------------------------------------+")
    #15. Obtenez les 3 prénoms d’utilisateurs les plus présents dans la base
    top_users_names = db.users.aggregate([
        {"$project": {"name": 1}},
        {"$group": {"_id": "$name", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": 3}
    ])
    for result in top_users_names:
        print(result["_id"])
    print("+----------------------------------------------------------------------------------------------------+")

# Connexion à MongoDB
try:
    conn = MongoClient()
    print("Connected successfully to MongoDB")
except:
    print("Could not connect to MongoDB")

# Sélection de la base de données
db = conn['mydatabase']

if len(sys.argv) <= 1:
    print("Error you need to specify which interrogation you want to display with a number between 1 - 15")
    exit(-1)

interrogation = int(sys.argv[1])

debut = time.time()

if interrogation == 1:
    requete_1(db)
elif interrogation == 2:
    requete_2(db)
elif interrogation == 3:
    requete_3(db)
elif interrogation == 4:
    requete_4(db)
elif interrogation == 5:
    requete_5(db)
elif interrogation == 6:
    requete_6(db)
elif interrogation == 7:
    requete_7(db)
elif interrogation == 8:
    requete_8(db)
elif interrogation == 9:
    requete_9(db)
elif interrogation == 10:
    requete_10(db)
elif interrogation == 11:
    requete_11(db)
elif interrogation == 12:
    requete_12(db)
elif interrogation == 13:
    requete_13(db)
elif interrogation == 14:
    requete_14(db)
elif interrogation == 15:
    requete_15(db)

fin = time.time()

temps_ecoule = fin - debut

print(f"La fonction a pris {temps_ecoule} secondes pour s'exécuter.")