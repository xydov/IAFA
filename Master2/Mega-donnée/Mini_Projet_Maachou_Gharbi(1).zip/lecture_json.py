import json
from pymongo import MongoClient
import numpy as np
import argparse
import string

def remove_punctuation_and_stopwords(text):
    # Retire la ponctuation et les stopwords
    stop_words = ['have', 'not', 'be', 're', 'wouldn', "weren't", 'myself', "couldn't",
                        'and', "don't", 'but', 'me', 'the', 'by', 'they', 'about', 'same',
                        'with', 'why', 'didn', 'mightn', 'them', "doesn't", 'when', 'now',
                        'most', 'some', 'yourselves', 'under', 'out', 'are', 'between', 'on',
                        'very', 'after', 'aren', 'then', 'an', 'down', 'or', 'haven', 'd', 've', 
                        'y', "you'll", 'him', 'is', 'having', 'off', 'further', 'any', 'nor', 'here',
                        "you'd", 'against', 'so', 'hers', 'each', 'too', "wouldn't", 'through', 'from',
                        'as', 'our', 'up', 'these', 'of', 't', "shouldn't", 'ma', 'yours', 'both', 'which',
                        'only', 'because', 'ourselves', 'her', 'i', 'a', "aren't", "you're", "mustn't", 'll',
                        'shan', 'themselves', "it's", 'o', 'at', "haven't", 'himself', 'm', 'his', 'he', 'whom', 
                        'she', 'other', "should've", 'ain', 'don', 'to', 'mustn', 's', 'does', 'did', 'for',
                        "you've", 'hadn', 'it', 'where', 'has', 'below', 'been', 'no', "wasn't", 'own', 'won', 
                        'weren', 'am', 'into', 'until', 'was', 'being', 'again', 'that', 'yourself', 'there', 'than', 
                        'isn', 'this', 'their', 'do', "won't", 'how', "mightn't", 'if', 'just', 'doing', 'over', 'can', 
                        'couldn', 'above', 'once', 'before', 'what', "needn't", 'itself', 'were', 'while', 'during',
                        'herself', 'theirs', 'those', "didn't", 'we', "isn't", 'its', 'in', 'doesn', "hadn't", 'you', 
                        "shan't", 'who', 'such', 'hasn', 'your', "she's", 'should', 'few', 'needn', 'ours', "hasn't", 
                        "that'll", 'my', 'wasn', 'shouldn', 'had', 'will', 'all', 'more']
    
    translator = str.maketrans("", "", string.punctuation)
    text_sans_ponct = text.translate(translator)
    stop_words = set(stop_words)

    # vectorizer = CountVectorizer(stop_words=stop_words, analyzer='word')
    # vectorizer.fit_transform(text)

    words = []
    words.extend([word.lower() for word in text_sans_ponct.split() if word.lower() not in stop_words])
    return list(set(words))

# Créer un objet ArgumentParser
parser = argparse.ArgumentParser(description='Script pour effectuer des opérations avec des paramètres.')

# Ajouter les arguments
parser.add_argument('--restaurants', type=str, required=True, help='URL restaurants')
parser.add_argument('--reviews', type=str, required=True, help='URL reviews')
parser.add_argument('--users', type=str, required=True, help='URL users')
parser.add_argument('--database_name', type=str)

args = parser.parse_args()

try:
    conn = MongoClient()
    print("Connected successfully!!!")

    #CREATE COLLECTIONS 
    if args.database_name != None:
        db = conn[args.database_name]
    else:
        db = conn["mydatabase"]
    if 'restaurants' in db.list_collection_names(): 
        db['restaurants'].drop()

    print("Collection 'restaurants' created.")
    db.create_collection('restaurants')

    if 'users' in db.list_collection_names():
        db['users'].drop()
    
    print("Collection 'users' created.")
    db.create_collection('users')
except:
    print("Could not connect to MongoDB Please Start your server")

# Chemin vers votre fichier JSON
file_path_users = args.users
file_path_reviews = args.reviews
file_path_restau = args.restaurants

# Ouvrir le fichier JSON en mode lecture
with open(file_path_users, 'r', encoding='utf-8') as file:
    # Charger le contenu du fichier dans une variable Python (dictionnaire ou liste)
    data_usr = json.load(file)

with open(file_path_reviews, 'r', encoding='utf-8') as file:
    # Charger le contenu du fichier dans une variable Python (dictionnaire ou liste)
    data_rev = json.load(file)

with open(file_path_restau, 'r', encoding='utf-8') as file:
    # Charger le contenu du fichier dans une variable Python (dictionnaire ou liste)
    data_rest = json.load(file)

users_collection = db["users"]
restau_collection = db["restaurants"]

user_data = []
reviews = {}
global_rating = {}
global_count = {}
rest_rev = {}
rest_users = {}
user_names = {}

for input_usr in data_usr:
    user_names[input_usr['user_id']] = input_usr['name']

for input_rev in data_rev:

    if input_rev["user_id"] in reviews:
        reviews[input_rev["user_id"]].append({
            "review_id" : input_rev["review_id"],
            "business_id"  : input_rev["business_id"],
            "rating" : input_rev["stars"],
            "text" : input_rev["text"],
            "word_bag" : remove_punctuation_and_stopwords(input_rev["text"])
        })
    else:
        reviews[input_rev["user_id"]] = [{
            "review_id" : input_rev["review_id"],
            "business_id"  : input_rev["business_id"],
            "rating" : input_rev["stars"],
            "text" : input_rev["text"],
            "word_bag" : remove_punctuation_and_stopwords(input_rev["text"])
        }]
    
    if input_rev["business_id"] in global_rating:
        global_rating[input_rev["business_id"]].append(input_rev["stars"])
    else:
        global_rating[input_rev["business_id"]] = [input_rev["stars"]]

    if input_rev["business_id"] in rest_rev:
        rest_rev[input_rev["business_id"]].append(input_rev["review_id"])
    else:
        rest_rev[input_rev["business_id"]] = [input_rev["review_id"]]

    if input_rev["business_id"] in rest_users:
        rest_users[input_rev["business_id"]].append({
            'user_id' : input_rev["user_id"],
            'name' : user_names[input_rev['user_id']]
            })
    else:
        rest_users[input_rev["business_id"]] = [{'user_id' : input_rev["user_id"],'name' : user_names[input_rev['user_id']]}]


rest_data = []
for input_res in data_rest: 
    if (input_res['attributes'] and ('Ambience' in input_res['attributes']) and (input_res['attributes']['Ambience'] != 'None')):
        ambience = [cle for cle, valeur in eval(input_res['attributes']['Ambience']).items() if valeur is True]
    else :
        ambience = []
    rest_data.append({
        "business_id": input_res["business_id"],
        "name": input_res["name"],
        "ville": input_res["city"],
        "categories": input_res["categories"].split(", "),
        "ambiences": ambience,
        "more_than_3" : int(len(ambience)>=3),
        "rating": np.mean(global_rating[input_res["business_id"]]),
        "reviews": rest_rev[input_res["business_id"]],
        "reviews_count": len(rest_rev[input_res["business_id"]]),
        "users": rest_users[input_res["business_id"]],
        'address': input_res['address'] 
  })



for input_usr in data_usr:
    user_data.append({
        'user_id' : input_usr['user_id'],
        'name' : input_usr['name'],
        'friends' : input_usr['friends'],
        'friends_count' : len(input_usr['friends']),
        'reviews' : reviews[input_usr["user_id"]]
        })
    
with open("restaurants.json", "w") as fichier_json:
    json.dump(rest_data, fichier_json)

with open("users.json", "w") as fichier_json:
    json.dump(user_data, fichier_json)
    
for user in user_data:
    users_collection.insert_one(user)

for restaurant in rest_data:
    restau_collection.insert_one(restaurant)


