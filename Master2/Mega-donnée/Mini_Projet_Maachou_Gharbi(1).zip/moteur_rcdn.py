from pymongo import MongoClient
import sys
import time
import numpy as np

def appreciation(db, ville):
    #Obtenez la liste des restaurants de la ville
    restaurants = db.restaurants.find({"ville": ville})
    appreciation_scores, restaurant_names = [], []

    #Obtenez le max nombre de reviews
    max_reviews_count = next(db.restaurants.aggregate([
        {"$match": {"ville": ville}},
        {"$sort": {"reviews_count": -1}},
        {"$limit": 1},
        { "$project": { "_id": 0, "reviews_count": 1 } }
    ]))["reviews_count"] 

    for restaurant in restaurants:
        #Pour chaque restaurant on calcule le score d'appreciation
        score = (restaurant['rating'] * restaurant['reviews_count']) / (5.0*max_reviews_count)
        appreciation_scores.append(score)
        restaurant_names.append(restaurant['name'])
    
    #Retourne la liste des scores et la liste des restaurants
    return appreciation_scores, restaurant_names

def preference(db, ville, user):
    restaurants = db.restaurants.find({"ville": ville})
    preference_scores, T_u = [], []

    # Obtenez les différentes catégories associées aux restaurants évalués par l’utilisateur d’identifiant Yelp user
    categories = list(db.users.aggregate([
        {"$match": {"user_id": user}}, # on filtre les utilisateurs ayant l'user_id égal à user.
        {"$unwind": "$reviews"}, # décomposer le tableau reviews pour traiter chaque element
        {"$lookup": {"from": "restaurants", "localField": "reviews.business_id", "foreignField": "business_id", "as": "restaurant_info"}}, # effectue une jointure entre les collections users et restaurants.
        {"$unwind": "$restaurant_info"}, # décomposer le tableau créé par la jointure parce que on peut avoir plusieurs restaurants évalués par un seul user
        {"$group": {"_id": "$restaurant_info.categories"}}, #  regroupe les documents en fonction de la valeur du champ categories.
    ]))

    # Obtenez les différentes ambiences associées aux restaurants évalués par l’utilisateur d’identifiant Yelp user
    ambiences = list(db.users.aggregate([
        {"$match": {"user_id": user}}, # on filtre les utilisateurs ayant l'user_id égal à user.
        {"$unwind": "$reviews"}, # décomposer le tableau reviews pour traiter chaque element
        {"$lookup": {"from": "restaurants", "localField": "reviews.business_id", "foreignField": "business_id", "as": "restaurant_info"}}, # effectue une jointure entre les collections users et restaurants.
        {"$unwind": "$restaurant_info"}, # décomposer le tableau créé par la jointure parce que on peut avoir plusieurs restaurants évalués par un seul user
        {"$group": {"_id": "$restaurant_info.ambiences"}}, #  regroupe les documents en fonction de la valeur du champ ambiences.
    ]))


    #Γu l’ensemble des critères (catégories+ambiences) préférés par l’utilisateur user
    for a in categories:
        T_u.extend(a["_id"])
        
    for b in ambiences:
        T_u.extend(b["_id"])
    
    
    T_u = set(T_u)

    #calculer jaccard score pour chaque restaurant
    for restaurant in restaurants:
        restaurant['categories'].extend(restaurant['ambiences'])
        T_r = set(restaurant['categories'])
        preference_scores.append(len(T_u & T_r) / len(T_u | T_r))
    
    #Retourne la liste des scores
    return preference_scores

def social(db, ville, user):
    #Obtenez la liste des restaurants de la ville
    restaurants = db.restaurants.find({"ville": ville})

    #Obtenez les attributs de user (dont la liste des amis)
    usr = next(db.users.find({"user_id": user}))
    social_score = []

    #Verifier s'il a des amis sinon on retourne 0 partout
    if usr['friends_count'] == 0:
        social_score = [0.0 for _ in restaurants]
        return social_score
    
    #Parcourir les restauarants de la ville
    for restaurant in restaurants:
            #Pour chaque restaurant on récupère la liste des rating donné par les amis de user
            user_reviews = list(db.users.aggregate([
                {"$match": {
                    "user_id": {"$in": usr['friends']}
                }},
                {"$unwind": "$reviews"},
                {"$match" : {"reviews.business_id": restaurant["business_id"]}},
                {"$project": {'_id': 0, "reviews.rating": 1}}
            ]))

            # Calcul la moyenne des rating donnés par les amis de user
            if(user_reviews!=[]):
                ratings = [v['reviews']['rating'] for v in user_reviews]
                social_score.append(np.array(ratings).mean()/5.0)
            else:
                social_score.append(0.0)

    
    return social_score

def commentaire(db, ville, user):
    #Obtenez la liste des restaurants de la ville
    restaurants = db.restaurants.find({"ville": ville})

    #Obtenez le sac à mot pour chaque review noté 5 pour le user
    user_reviews = list(db.users.aggregate([
        {"$match": {"user_id": user}},
        {"$unwind": "$reviews"},
        {"$match": {"reviews.rating": 5.0}},
        {"$project": {'_id': 0, "reviews.word_bag": 1,"reviews.business_id": 1}}
    ]))

    stared_rest = {}
    V_stared_rest = {}
    if len(user_reviews) != 0:
        for review in user_reviews:
            if review['reviews']['business_id'] in stared_rest:
                stared_rest[review['reviews']['business_id']].extend(review['reviews']['word_bag'])
            else:
                stared_rest[review['reviews']['business_id']] = review['reviews']['word_bag']
        
        for key, value in stared_rest.items():
            V_stared_rest[key] = set(value)
    else:
        return [0.0 for _ in restaurants]

    commentaire_score = []
    
    #Parcourir les restauarants de la ville
    for restaurant in restaurants:

        #Obtenez le sac à mot pour chaque review du restaurant
        other_reviews = list(db.users.aggregate([
            {"$match": {"reviews.business_id": restaurant["business_id"]}},
            {"$project": {'_id': 0, "reviews.word_bag": 1, "user_id": 1}}
        ]))

        V_user_rest, user_rest = {}, {}
        if len(other_reviews) != 0:
            for review in other_reviews:
                user_rest[review['user_id']] = []

                for text in review['reviews']:
                    user_rest[review['user_id']].extend(text['word_bag'])

            
            for key, value in user_rest.items():
                V_user_rest[key] = set(value)
        
            score_local = 0.0

            #on calcule le max de l'indice de jaccard pour le scouple de sac à mot V(u, r') et V(u', r)
            for _, v1 in V_stared_rest.items():
                for _, v2 in V_user_rest.items():
                    # Calcul de l'indice Jaccard
                    intersection = len(v1.intersection(v2))
                    union = len(v1.union(v2))
                    score = intersection / union if union > 0 else 0.0
                    if score > score_local:
                        score_local = score

        commentaire_score.append(score_local)  


 
    
    return commentaire_score

def scores(appreciation_scores, preference_scores, social_scores, commentaire_scores):
    alpha = 0.30
    beta = 0.35
    gamma = 0.20
    lamda = 0.15
    final_score = []
    
    for appreciation_score, preference_score, social_score, commentaire_score in zip(appreciation_scores, preference_scores, social_scores, commentaire_scores):
        final_score.append(alpha*appreciation_score + beta*preference_score + gamma*social_score + lamda*commentaire_score)

    return final_score

def display(restaurants, user, ville, scores, appreciation_scores, preference_scores, social_scores, commentaire_scores):

    user_info = "User: "+user+" / City: "+ville

    # En-tête du tableau
    table_header = "+------+-------------------------------------------+---------------------+--------+--------+----------+-----------+"
    table_columns= "| Rank |                   Name                    |        Score        |  appr  |  pref  |  social  |  comment  |"

    print(user_info)
    print(table_header)
    print(table_columns)
    print(table_header)
    rank = 1

    for restaurant, score, appreciation_score, preference_score, social_score, commentaire_score in zip(restaurants, scores, appreciation_scores, preference_scores, social_scores, commentaire_scores):
        name = restaurant
        score = score
        f1 = appreciation_score
        f2 = preference_score
        f3 = social_score
        f4 = commentaire_score
    
        table_row = f"| {rank:3d}  | {name:41s} | {score:.17f} | {f1:.4f} | {f2:.4f} | {f3:.6f} | {f4:.7f} |"
    
        print(table_row)
        rank += 1
    
    print(table_header)




if len(sys.argv) != 3:
    print("Error you need to specify which user and city you want to display the recommandation")
    exit(-1)

ville = sys.argv[2]
user = sys.argv[1]

# Connexion à MongoDB
try:
    conn = MongoClient()
    print("Connected successfully to MongoDB")
except:
    print("Could not connect to MongoDB")

# Sélection de la base de données
db = conn['mydatabase']
debut = time.time()

appreciation_scores, restaurant_names = appreciation(db, ville)
preference_scores = preference(db, ville, user)
social_scores = social(db, ville, user)
commentaire_scores = commentaire(db, ville, user)

#calcul de score global
score = scores(appreciation_scores, preference_scores, social_scores, commentaire_scores)
score_results = np.array(score)

#trié les restaurant par score
args = np.argsort(score_results)[::-1]
score_results = score_results[args][:20]
restaurant_names = np.array(restaurant_names)[args][:20]
fin = time.time()

temps_ecoule = fin - debut

#affichage des infos
appreciation_scores = np.array(appreciation_scores)[args]
preference_scores = np.array(preference_scores)[args]
social_scores = np.array(social_scores)[args]
commentaire_scores = np.array(commentaire_scores)[args]
display(restaurant_names, user, ville, score_results, appreciation_scores, preference_scores, social_scores, commentaire_scores)
print(f"La fonction a pris {temps_ecoule} secondes pour s'exécuter.")